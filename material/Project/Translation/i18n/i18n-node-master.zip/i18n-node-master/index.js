module.exports = require('./i18n');
