Roadmap
========
* better parsing of defaults (and adding more reasonable default settings)
* lot's of more configure settings
* better sanitation in all fs operations => plugin system for storage
* ~named parameters in translation strings~
* api docs
